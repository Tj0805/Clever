$(document).ready(function(){
  $("#begin").hide();
  $("#additionGame").hide();
  $("#resultEnd").hide();
  $("#first,#second,#answer").hide();
  var countdownN = 3; //countdown for the game
  var right = 0;
  var wrong = 0;
  var countis = 30; //timer for the game
  countdown = setInterval(function(){
    countdownN--;
    $(".count").text(countdownN);
    if(countdownN<0){
      clearInterval(countdown);
      $(".count").css("animation","none");
      $("#countdown").hide();}
  },1000);
  additionGame();
   $("#go").click(function(){
  });//go !
  function additionGame(){
    var answer = $("#userAnswer").val();
    var ans = parseInt(answer);
    var num1 = Math.floor(Math.random()*100);
    var num2 = Math.floor(Math.random()*100);
    var result = num1 + num2;
    $("#first").text(num1);
    $("#second").text(num2);
    $("#answer").text(result);
    $("#need").text(num1+" + "+num2)
  };//game();
  setTimeout(function(){
    $("#additionGame").show();
    countup = setInterval(function(){
    countis-=1;
    $("#countis").text(countis+":00");
    if(countis<=0){ //when game time is finished
     $(".endresult").html("Total Tries :"+(right+wrong)+"<br>Right: "+right+"<br>Wrong :"+wrong+"<br>Correct answer percentage: "+(Math.floor((right*100)/(right+wrong)))+"%")
      clearInterval(countup);
      $("#countis").text("00:00");
      $("#html").hide();
      $("#resultEnd").show(); //shows the results
    }
  },1000);
  },4100);
  $('#useranswer').keypress(function (e) {
  if (e.which == 13) {
     var number1 = $("#first").text();
    var number2 = $("#second").text();
    var number3 = $("#useranswer").val();
    var n1 = parseInt(number1);
    var n2 = parseInt(number2);
    var n3 = parseInt(number3);
    var n4 = n1 + n2;
     if(n3==n4){
       right++; //for the percentages
     }
     else{
       wrong++;
     }
      game();
    $(this).val("");
  }//if
});//keypress
});